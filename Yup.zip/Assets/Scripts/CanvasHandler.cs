﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class CanvasHandler : MonoBehaviour {

	public GameObject weaponObject;
	private Weapon weaponScript;
	public RectTransform rectical;
	public Text pickupText;
	public Text pickupTextPrefab;
	public Text ammoText;
	void Start () {
		ammoText.text = weaponScript.getClipAmount ().ToString() + "/" + weaponScript.getClipSize ().ToString();

	}
	
	// Update is called once per frame
	void Update () {
		ammoText.text = weaponScript.getClipAmount ().ToString() + "/" + weaponScript.getClipSize ().ToString();
	
	}

	public void setWeaponObject(GameObject weapon) {
		this.weaponObject = weapon;
		weaponScript = (Weapon)weaponObject.GetComponent (typeof(Weapon));
		rectical.gameObject.SetActive (true);
	}

	public void fireBullet() {
		weaponScript.fireGun ();
		ammoText.text = weaponScript.getClipAmount ().ToString() + "/" + weaponScript.getClipSize ().ToString();
	}

	public Weapon getWeaponScript() {
		return weaponScript;
	}

	public void creatText(string name) {
		if (pickupText == null) {
			pickupText = (Text)Instantiate (pickupTextPrefab);
			pickupText.transform.SetParent(transform, false);
			pickupText.text = "Press 'k' to pickup' " + name;
		}
	}

	public void pickupOrLeave() {
		Destroy (GameObject.Find (pickupText.name));
	}

}
